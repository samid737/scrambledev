---
layout: page
title: About
tagline: A few more words about this theme
permalink: /about.html
---

This is the _Cayman Blog_ Jekyll theme. You can find out more info about customizing this theme, as well as basic usage documentation, and source code at: [cayman-blog](https://github.com/lorepirri/cayman-blog)

You can find the source code for _Jekyll_ at [jekyll](https://github.com/jekyll/jekyll)


[Go to the Home Page]({{ site.url }}{{ site.baseurl }})
